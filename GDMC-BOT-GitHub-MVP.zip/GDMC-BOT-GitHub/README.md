# GDMC BOT — GitHub Pages MVP

A professional static website + interactive maintenance governance dashboard for GDMC BOT.

## Included
- Public landing page
- Control Center dashboard
- Five approved maintenance statuses
- Search and status filtering
- Demo request creation
- Responsive mobile layout
- GitHub Actions deployment to GitHub Pages

## Deploy
1. Create a new GitHub repository, e.g. `gdmc-bot`.
2. Upload all files from this project to the repository root.
3. Commit to `main`.
4. Open **Settings → Pages → Build and deployment**.
5. Set **Source = GitHub Actions**.
6. Open **Actions** and wait for the deployment to finish.
7. GitHub Pages will provide the live URL.

GitHub Pages is static hosting. This MVP stores demo data in browser memory only. For production, connect the dashboard to a real backend/database and never put API secrets in frontend code.

## Production roadmap
WhatsApp API → Make → secure backend/database → dashboard → notifications → reports.
