const requests=[
{id:'GDMC-2026-00125',employee:'Ahmed Ali',location:'Office',type:'Electrical',status:'Waiting for Supervisor Approval',updated:'8 min ago'},
{id:'GDMC-2026-00124',employee:'Mohammed Saad',location:'Housing',type:'AC',status:'In Progress',updated:'21 min ago'},
{id:'GDMC-2026-00123',employee:'Sara Omar',location:'Other Facilities',type:'Plumbing',status:'Waiting for Spare Parts',updated:'1 hr ago'},
{id:'GDMC-2026-00122',employee:'Khalid Nasser',location:'Office',type:'Lighting',status:'Waiting for Finance Approval',updated:'2 hrs ago'},
{id:'GDMC-2026-00121',employee:'Faisal Ahmed',location:'Housing',type:'Plumbing',status:'Finished',updated:'3 hrs ago'},
{id:'GDMC-2026-00120',employee:'Nora Saleh',location:'Office',type:'AC',status:'In Progress',updated:'4 hrs ago'},
{id:'GDMC-2026-00119',employee:'Omar Hassan',location:'Other Facilities',type:'Electrical',status:'Finished',updated:'5 hrs ago'}
];
function cls(s){if(s.includes('Supervisor'))return'wait';if(s==='In Progress')return'progress';if(s.includes('Spare'))return'parts';if(s.includes('Finance'))return'finance';return'finished'}
function renderTable(){const q=(document.getElementById('search').value||'').toLowerCase(), f=document.getElementById('statusFilter').value;const data=requests.filter(r=>(f==='All statuses'||r.status===f)&&Object.values(r).join(' ').toLowerCase().includes(q));document.getElementById('requestRows').innerHTML=data.map(r=>`<tr><td><b>${r.id}</b></td><td>${r.employee}</td><td>${r.location}</td><td>${r.type}</td><td><span class="status ${cls(r.status)}">${r.status}</span></td><td>${r.updated}</td></tr>`).join('')}
function newRequest(){const id='GDMC-2026-'+String(126+Math.floor(Math.random()*800)).padStart(5,'0');requests.unshift({id,employee:'Demo Employee',location:'Office',type:'Other',status:'Waiting for Supervisor Approval',updated:'just now'});document.getElementById('total').textContent=128+1;document.getElementById('waiting').textContent=19;renderTable();alert('Demo request created: '+id)}
renderTable();